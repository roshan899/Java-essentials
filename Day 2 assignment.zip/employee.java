package com.main;

public class employee {
public String name;
public int age;
public String city;

public void display(){
  System.out.println("The name is "+name);
  System.out.println("The age is "+age);
  System.out.println("The city is "+city);
  
}

}