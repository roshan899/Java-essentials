package com.main;

import java.util.Scanner;
public class marks {

  public static void main(String[] args) {
  
  
   Scanner sc=new Scanner(System.in);
  int hin, eng, bio, chem, phy;
  double total, average, percentage;
  
  
  System.out.println("Enter marks of 5 subjects");
  System.out.print("Enter marks obtained in Hindi: ");
  hin=sc.nextInt();
  System.out.print("Enter marks obtained in English: ");
  eng=sc.nextInt();
  System.out.print("Enter marks obtained in Bio: ");
  bio=sc.nextInt();
  System.out.print("Enter marks obtained in Chemistry: ");
  chem=sc.nextInt();
  System.out.print("Enter marks obtained in Physics: ");
  phy=sc.nextInt();
  
  
  total = hin + eng + bio + chem + phy;
  average = (total / 5);
  percentage = (total/500) * 100;
  
  
 if (percentage>=80){
   System.out.println("Grade A");
 }
 
 else if (percentage>=60 && percentage<80){
   System.out.println("Grade B");
 }
 
 else if (percentage>=45 && percentage<60){
   System.out.println("Grade C");
 }
 
 else if (percentage>=30 && percentage<45){
   System.out.println("Grade D");
 }
 
 else{
   System.out.println("You failed,study hard");
 }
  
  
  
  
  System.out.println("Total marks = " +total + " out of 500");
  System.out.println("Average marks = " +average);
  System.out.println("Percentage = " +percentage);
  
  }



  }

